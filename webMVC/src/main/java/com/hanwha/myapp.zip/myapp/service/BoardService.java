package com.hanwha.myapp.service;

import java.util.List;

import com.hanwha.myapp.vo.BoardVO;
import com.hanwha.myapp.vo.pagingVO;

public interface BoardService {
		public int boardWriteOk(BoardVO vo);
		public int totalRecord();
		public List<BoardVO> boardList(pagingVO pVO);
}

